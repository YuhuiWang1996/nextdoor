// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportLogin = require('../../../app/controller/login');
import ExportRegister = require('../../../app/controller/register');
import ExportBlockNewresident = require('../../../app/controller/block/newresident');
import ExportBlockResident = require('../../../app/controller/block/resident');
import ExportForumMessage = require('../../../app/controller/forum/message');
import ExportForumThread = require('../../../app/controller/forum/thread');
import ExportForumTopic = require('../../../app/controller/forum/topic');
import ExportHoodResident = require('../../../app/controller/hood/resident');
import ExportRelationFriend = require('../../../app/controller/relation/friend');
import ExportRelationNeighbor = require('../../../app/controller/relation/neighbor');
import ExportSettingAccount = require('../../../app/controller/setting/account');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    login: ExportLogin;
    register: ExportRegister;
    block: {
      newresident: ExportBlockNewresident;
      resident: ExportBlockResident;
    }
    forum: {
      message: ExportForumMessage;
      thread: ExportForumThread;
      topic: ExportForumTopic;
    }
    hood: {
      resident: ExportHoodResident;
    }
    relation: {
      friend: ExportRelationFriend;
      neighbor: ExportRelationNeighbor;
    }
    setting: {
      account: ExportSettingAccount;
    }
  }
}
