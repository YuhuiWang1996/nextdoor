// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuz = require('../../../app/middleware/auz');

declare module 'egg' {
  interface IMiddleware {
    auz: typeof ExportAuz;
  }
}
